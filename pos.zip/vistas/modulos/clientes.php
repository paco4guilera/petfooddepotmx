<!-- Content Wrapper. Contains page content -->
<div class="content-wrapper">
    <!-- Content Header (Page header) -->
    <section class="content-header">
        <h1>
            Clientes

        </h1>
        <ol class="breadcrumb">
            <li>
                <a href="#"><i class="fa fa-dashboard"></i> Inicio</a>
            </li>
            <li class="active">Clientes</li>
        </ol>
    </section><!-- Base -->

    <section class="content">
        <!-- Default box -->
        <div class="box">
            <div class="box-header with-border">
                <button class="btn btn-primary" data-toggle="modal" data-target="#modalAgregarCliente">
                    Agregar Cliente
                </button>
            </div>
            <div class="box-body">
                <!-- <table class="table table-bordered table-striped tablas"> -->
                <table class="table table-bordered table-condensed  table-hover dt-responsive tabla-plugin">
                    <thead>
                        <tr>
                            <th style="width: 15px;">ID</th>
                            <th>Nombre</th>
                            <th>Teléfono</th>
                            <th>Correo</th>
                            <th>Colonia</th>
                            <th>Tipo</th>
                            <th>Puntos</th>
                            <th>Crédito</th>
                            <th>Deuda</th>
                            <th>Sesión</th>
                            <th>Acciones</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php 
                        $item=null;
                        $valor=null;
                        $usuarios= ControladorClientes::ctrMostrarClientes($item,$valor);
                        foreach($usuarios as $key=>$value){
                            echo '<tr>
                            <td>'.$value["cliente_id"].'</td>
                            <td>'.$value["cliente_nombre"].'</td>
                            <td>'.$value["cliente_telefono"].'</td>
                            <td>'.$value["cliente_correo"].'</td>
                            <td>'.$value["cliente_colonia"].'</td>
                            <td>'.$value["cliente_tipo"].'</td>
                            <td>'.$value["cliente_puntos"].'</td>
                            <td>'.'$ '.$value["cliente_credito"].'</td>
                            <td>'.'$ '.$value["cliente_deuda"].'</td>
                            ';
                            echo'<td>'.$value["sesion_id"].'</td>
                            <td>
                                <div class="btn-group">
                                    <button class="btn btn-warning btnEditarCliente" idCliente="'.$value["cliente_id"].'" data-toggle="modal" data-target="#modalEditarCliente">
                                        <i class="fa fa-pencil"></i>
                                    </button>
                                    <button class="btn btn-danger btnEliminarCliente" idCliente="'.$value["cliente_id"].'">
                                        <i class="fa fa-times"></i>
                                    </button>
                                </div>
                            </td>
                        </tr>';
                        }
                        ?>
                    </tbody>
                </table>
            </div>
            <!-- /.box-body -->

        </div>
        <!-- /.box -->
    </section>
    <!-- /.content -->
</div>
<!-- /.content-wrapper -->
<div id="modalAgregarCliente" class="modal fade" role="dialog">

    <div class="modal-dialog">
        <!-- Modal content-->
        <div class="modal-content">
            <form role="form" method="post" enctype="multipart/form-data">
                <div class="modal-header" style="background:#3c8dbc; color:white">
                    <button type=" button" class="close" data-dismiss="modal">&times;</button>
                    <h4 class="modal-title">Registro de Cliente</h4>
                </div>
                <div class="modal-body">
                    <div class="box-body">

                        <div class="form-group">
                            <!-- Input para el Nombre -->
                            <div class="input-group">
                                <span class="input-group-addon"><i class="fa fa-user"></i></span>
                                <input type="text" class="form-control input-lg" name="nuevoNombre" id="nuevoNombre"
                                    placeholder="Nombre Completo" required>
                            </div>
                        </div><!-- Input para el nombre -->

                        <div class="form-group">
                            <!-- Input para el telefono -->
                            <div class="input-group">
                                <span class="input-group-addon"><i class="fa fa-phone"></i></span>
                                <input type="tel" class="form-control input-lg" name="nuevoTelefono" id="nuevoTelefono"
                                    placeholder="Teléfono" required>
                            </div>
                        </div><!-- Input para el telefono -->

                        <div class="form-group">
                            <!-- Input para la email -->
                            <div class="input-group">
                                <span class="input-group-addon"><i class="fas fa-at"></i></span>
                                <input type="email" class="form-control input-lg" name="nuevoEmail" id="nuevoEmail"
                                    placeholder="E-mail" required>
                            </div>
                        </div><!-- Input para la email -->
                        <div class="form-group">
                            <!-- Input para la Colonia -->
                            <div class="input-group">
                                <span class="input-group-addon"><i class="fas fa-home"></i></span>
                                <input type="text" class="form-control input-lg" name="nuevaColonia"
                                    placeholder="Colonia" required>
                            </div>
                        </div><!-- Input para la Colonia -->
                        <div class="form-group">
                            <!-- Input para el tipo -->
                            <div class="input-group">
                                <span class="input-group-addon"><i class="fa fa-users"></i></span>
                                <select class="form-control input-lg" name="nuevoTipo">
                                    <option value="">Seleccionar tipo</option>
                                    <option value="Mayorista">Mayorista</option>
                                    <option value="Veterinaria">Veterinaria</option>
                                    <option value="Detalle">Detalle</option>
                                    <option value="Final">Final</option>
                                </select>
                            </div>
                        </div><!-- Input para el rol -->
                        <!-- <div class="form-group">
                            <div class="panel">SUBIR FOTO</div>
                            <input type="file" class="nuevaFoto" name="nuevaFoto">
                            <p class="help-block">Peso máximo: 2 MB</p>
                            <img src="vistas/img/usuarios/default/anonymous.png" class="img-thumbnail previsualizar"
                                width="100px" alt="foto usuario por defecto">
                        </div> -->
                    </div>
                </div>
                <div class="modal-footer">

                    <button type="button" class="btn btn-default pull-left" data-dismiss="modal">Cerrar</button>
                    <button type="submit" class="btn btn-primary ">Guardar</button>
                </div>
                <?php 
                    $crearCliente= new ControladorClientes();
                    $crearCliente-> ctrCrearCliente();
                ?>
            </form>
        </div>

    </div>
</div>
<!-- -------------------------------------------------------------------------------------------------------------- -->
<!-- Modal editar cliente -->
<div id="modalEditarCliente" class="modal fade" role="dialog">
    <div class="modal-dialog">
        <!-- Modal content-->
        <div class="modal-content">
            <form role="form" method="post" enctype="multipart/form-data">
                <div class="modal-header" style="background:#3c8dbc; color:white">
                    <button type=" button" class="close" data-dismiss="modal">&times;</button>
                    <h4 class="modal-title">Editar de Cliente</h4>
                </div>
                <div class="modal-body">
                    <div class="box-body">

                        <div class="form-group">
                            <!-- Input para el Nombre -->
                            <div class="input-group">
                                <span class="input-group-addon"><i class="fa fa-user"></i></span>
                                <input type="hidden" id="idActual" name="idActual">
                                <input type="text" class="form-control input-lg" name="editarNombre" id="editarNombre"
                                    placeholder="Nombre Completo" required>
                            </div>
                        </div><!-- Input para el nombre -->

                        <div class="form-group">
                            <!-- Input para el telefono -->
                            <div class="input-group">
                                <span class="input-group-addon"><i class="fa fa-phone"></i></span>
                                <input type="tel" class="form-control input-lg" id="editarTelefono"
                                    name="editarTelefono" placeholder="Teléfono" required>
                            </div>
                        </div><!-- Input para el telefono -->

                        <div class="form-group">
                            <!-- Input para la email -->
                            <div class="input-group">
                                <span class="input-group-addon"><i class="fas fa-at"></i></span>
                                <input type="email" class="form-control input-lg" id="editarEmail" name="editarEmail"
                                    placeholder="E-mail" required>
                            </div>
                        </div><!-- Input para la email -->
                        <div class="form-group">
                            <!-- Input para la Colonia -->
                            <div class="input-group">
                                <span class="input-group-addon"><i class="fas fa-home"></i></span>
                                <input type="text" class="form-control input-lg" id="editarColonia" name="editarColonia"
                                    placeholder="Colonia" required>
                            </div>
                        </div><!-- Input para la Colonia -->
                        <div class="form-group">
                            <!-- Input para el tipo -->
                            <div class="input-group">
                                <span class="input-group-addon"><i class="fa fa-users"></i></span>
                                <select class="form-control input-lg" name="editarTipo">
                                    <option value="" id="editarTipo"></option>
                                    <option value="Mayorista">Mayorista</option>
                                    <option value="Veterinaria">Veterinaria</option>
                                    <option value="Detalle">Detalle</option>
                                    <option value="Final">Final</option>
                                </select>
                            </div>
                        </div><!-- Input para el rol -->
                    </div>
                </div>
                <div class="modal-footer">

                    <button type="button" class="btn btn-default pull-left" data-dismiss="modal">Cerrar</button>
                    <button type="submit" class="btn btn-primary ">Guardar</button>
                </div>
                <?php 
                    $editarCliente= new ControladorClientes();
                    $editarCliente-> ctrEditarCliente();
                ?>
            </form>
        </div>

    </div>
</div>
<?php 
                $borrarCliente= new ControladorClientes();
                $borrarCliente-> ctrBorrarCliente();
                ?>