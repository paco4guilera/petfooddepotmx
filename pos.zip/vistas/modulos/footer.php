<footer class="main-footer">
    <strong>Copyright &copy; 2020. </strong>
    Todos los derechos reservados.
    <div>Iconos diseñados por <a href="http://www.freepik.com/" title="Freepik">Freepik</a> from <a
            href="https://www.flaticon.es/" title="Flaticon">www.flaticon.es</a>
    </div>
</footer>