<aside class="main-sidebar">
    <section class="sidebar">
        <ul class="sidebar-menu">
            <li class="active">
                <a href="inicio">
                    <i class="fa fa-home"></i>
                    <span>Inicio</span>
                </a>
            </li>
            <li>
                <a href="usuarios">
                    <i class="fa fa-user"></i>
                    <span>Usuarios</span>
                </a>
            </li>
            <li>
                <a href="mascotas">
                    <i class="fa fa-paw"></i>
                    <span>Mascotas</span>
                </a>
            </li>
            <li>
                <a href="productos">
                    <i class="fas fa-bone"></i>
                    <span> Productos</span>
                </a>
            </li>
            <li>
                <a href="clientes">
                    <i class="fa fa-users"></i>
                    <span>Clientes</span>
                </a>
            </li>
            <li>
                <a href="agenda">
                    <i class="fa fa-calendar"></i>
                    <span>Agenda</span>
                </a>
            </li>
            <li>
                <a href="sucursales">
                    <i class="fas fa-store"></i>
                    <span>Sucursales</span>
                </a>
            </li>
            <li class="treeview menu-open">
                <a href="ventas">
                    <!-- <i class="fa fa-list-ul"></i> -->
                    <!-- <i class="fas fa-dollar-sign"></i> -->
                    <i class="fas fa-hand-holding-usd"></i>
                    <span> Ventas</span>
                    <span class="pull-right-container">
                        <i class="fa fa-angle-left pull-right"></i>
                    </span>
                </a>
                <ul class="treeview-menu" style="display: block;">
                    <li><a href="vender">
                            <i class="fas fa-cash-register"></i>
                            <span> Vender</span>
                        </a>
                    </li>
                    <li><a href="reporte-ventas">
                            <!--<i class="fa fa-circle-o"></i>  -->
                            <i class="fas fa-file-invoice-dollar"></i>
                            <span> Reporte de ventas</span>
                        </a>
                    </li>
                </ul>
            </li>
        </ul>
    </section>
</aside>