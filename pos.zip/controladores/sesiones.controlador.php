<?php
class ControladorSesiones{
    static public function ctrSesion(){
        
    }
}