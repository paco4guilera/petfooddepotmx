<?php
class ControladorMascotas{

    static public function ctrCrearMascota(){
        if(isset($_POST["nuevoNombre"])){
            if(preg_match('/^[-a-zA-Z0-9ñÑáéíóúÁÉÍÓÚ ]+$/', $_POST["nuevoNombre"])){
                    $tabla="mascotas";
                    $datos=array(
                                "nombre"=> $_POST["nuevoNombre"],
                                "raza"=> $_POST["nuevaRaza"],
                                "peso"=> $_POST["nuevoPeso"],
                                "edad"=> $_POST["nuevaEdad"],
                                "duegno"=> $_POST["nuevoDuegno"],
                                "sesion"=>$_SESSION["sesion"]
                                );
                    
                    $respuesta = ModeloMascotas::mdlIngresarMascota($tabla,$datos);
                    if($respuesta=="ok"){
                        echo'<script>
                    swal.fire({
                        icon:"success",
                        title: "Mascota registrada con éxito",
                        showConfirmButton: true,
                        confirmButtonText: "Cerrar",
                        closeOnConfirm: false 
                    }).then((result)=>{
                        if(result.value){
                            window.location="mascotas";
                        }
                    });
                    </script>';
                    }   else{
                        echo'<script>
                    swal.fire({
                        icon:"error",
                        title: "Mascota no registrada con éxito",
                        showConfirmButton: true,
                        confirmButtonText: "Cerrar",
                        closeOnConfirm: false 
                    }).then((result)=>{
                        if(result.value){
                            window.location="mascotas";
                        }
                    });
                    </script>';
                    }   
                
                }else{
                    echo'<script>
                    swal.fire({
                        icon:"error",
                        title: "¡No dejes campos vacíos! ",
                        showConfirmButton: true,
                        confirmButtonText: "Cerrar",
                        closeOnConfirm: false
                    }).then((result)=>{
                        if(result.value){
                            window.location="mascotas";
                        }
                    });
                    </script>';
                }
        }
    }
    static public function ctrMostrarMascotas($item,$valor){
        $tabla="mascotas";
        $respuesta = ModeloMascotas::MdlMostrarMascotas($tabla,$item,$valor);
        return $respuesta;
    }
    /* Editar usuario */
    static public function ctrEditarMascota(){
            if(isset($_POST["editarNombre"])){
                if(preg_match('/^[-a-zA-Z0-9ñÑáéíóúÁÉÍÓÚ ]+$/', $_POST["editarNombre"])&&
                    preg_match('/^[0-9]+$/', $_POST["editarPeso"])){
                    $tabla="mascotas";
                        $datos = array( "id" => $_POST["idActual"],
                                        "nombre" => $_POST["editarNombre"],
                                        "raza" => $_POST["editarRaza"],
                                        "peso" => $_POST["editarPeso"],
                                        "edad" => $_POST["editarEdad"]
                                    );
                        $respuesta=ModeloMascotas::mdlEditarMascota($tabla,$datos);
                        if($respuesta=="ok"){
                            echo'<script>
                    swal.fire({
                        icon:"success",
                        title: "Mascota modificada con éxito",
                        showConfirmButton: true,
                        confirmButtonText: "Cerrar",
                        closeOnConfirm: false 
                    }).then((result)=>{
                        if(result.value){
                            window.location="mascotas";
                        }
                    });
                    </script>';
                            }/* else{
                                echo'<script>
                    swal.fire({
                        icon:"error",
                        title: "Mascota no modificada con éxito",
                        showConfirmButton: true,
                        confirmButtonText: "Cerrar",
                        closeOnConfirm: false 
                    }).then((result)=>{
                        if(result.value){
                            window.location="mascotas";
                        }
                    });
                    </script>';
                            } */
                        }else{
                echo'<script>
                    swal.fire({
                        icon:"error",
                        title: "Verifique los datos ingresados",
                        showConfirmButton: true,
                        confirmButtonText: "Cerrar",
                        closeOnConfirm: false
                    }).then((result)=>{
                        if(result.value){
                            window.location="mascotas";
                        }
                    });
                    </script>';
                }
            }
    }
    /* Borrar usuario */
    static public function ctrBorrarMascota(){
        if(isset($_GET["idMascota"])){
            $tabla="mascotas";
            $datos=$_GET["idMascota"];
            $respuesta=ModeloMascotas::mdlBorrarMascota($tabla,$datos);
            if($respuesta=="ok"){
                echo'<script>
                    swal.fire({
                        icon:"success",
                        title: "Mascota eliminada con éxito",
                        showConfirmButton: true,
                        confirmButtonText: "Cerrar",
                        closeOnConfirm: false 
                    }).then((result)=>{
                        if(result.value){
                            window.location="mascotas";
                        }
                    });
                    </script>';
            }else{
                echo'<script>
                    swal.fire({
                        icon:"error",
                        title: "Mascota no eliminada con éxito",
                        showConfirmButton: true,
                        confirmButtonText: "Cerrar",
                        closeOnConfirm: false 
                    }).then((result)=>{
                        if(result.value){
                            window.location="mascotas";
                        }
                    });
                    </script>';
            }
        }
    }
}