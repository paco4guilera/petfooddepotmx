<?php
class ControladorClientes{

    // static public function ctrIngresoUsuario(){
    //     if(isset($_POST["ingUsuario"])){
    //         if(preg_match('/^[-a-zA-Z0-9]+$/', $_POST["ingUsuario"])&&
    //         preg_match('/^[-a-zA-Z0-9]+$/', $_POST["ingPassword"])
    //         ){
    //             $encriptar = crypt($_POST["ingPassword"],'$2a$07$asxx54ahjppf45sd87a5a4dDDGsystemdev$');
    //             $tabla="usuarios";
    //             $item= "usuario_login";
    //             $valor=$_POST["ingUsuario"];
    //             $respuesta = ModeloUsuarios::MdlMostrarUsuarios($tabla,$item,$valor);
    //             /* Aquí va la llamada del metodo de modelo de sesiones para registrar el inicio de sesion */
    //                     // $sesion= new ControladorSesiones();
    //                     // $sesion-> ctrSesion(); ModeloUsuarios::MdlMostrarUsuarios($tabla,$item,$valor);
    //                     //guardar la id de sesion en una variable
    //             //var_dump($respuesta);
    //             if($respuesta["usuario_login"]==$_POST["ingUsuario"]&&
    //                 $respuesta["usuario_password"]== $encriptar){
    //                     if( $respuesta["usuario_estado"]=="1"){
    //                     //echo'<br><div class="alert alert-success">Bienvenido</div>';
    //                     $_SESSION["iniciarSesion"]="ok";
    //                     $_SESSION["login"]= $respuesta["usuario_login"];
    //                     $_SESSION["nombre"]= $respuesta["usuario_nombre"];
    //                     $_SESSION["rol"]= $respuesta["usuario_rol"];
    //                     $_SESSION["foto"]= $respuesta["usuario_foto"];
    //                     //Sacar la fecha y hora para hacer el registro de sesión

    //                     date_default_timezone_set('America/Mexico_City');
    //                         $fecha= date('Y-m-d');
    //                         $hora = date('H:i:s');
    //                         $fechaActual= $fecha.' '.$hora;

    //                         $usuario= $respuesta["usuario_login"];
    //                         $inicioSesion= ModeloSesiones::mdlCrearSesion($fechaActual,$usuario);
    //                         //var_dump($inicioSesion);
    //                         if($inicioSesion["MAX(sesion_id)"]!=0){
    //                             $_SESSION["sesion"]=$inicioSesion["MAX(sesion_id)"];
    //                             echo '<script>
    //                             window.location = "inicio";
    //                             </script>';
    //                         }else{
    //                             $_SESSION["iniciarSesion"]="error";
    //                             echo'<br><div class="alert alert-danger">Error al iniciar sesion, intente de nuevo</div>';
    //                             }
                        
    //                     }else{
    //                         echo'<br><div class="alert alert-danger">Usuario desactivado</div>';
    //                     }
    //             }else{

    //                 echo'<br><div class="alert alert-danger">Error en los datos, vuelve a intentar</div>';
    //                 } 
                
    //         }

    //     }
    // }
    static public function ctrCrearCliente(){
        if(isset($_POST["nuevoNombre"])){
            if(preg_match('/^[-a-zA-Z0-9ñÑáéíóúÁÉÍÓÚ ]+$/', $_POST["nuevoNombre"])&&
                preg_match('/^[0-9]+$/', $_POST["nuevoTelefono"])){
                    $tabla="clientes";
                    $datos=array(
                                "nombre"=> $_POST["nuevoNombre"],
                                "telefono"=> $_POST["nuevoTelefono"],
                                "correo"=> $_POST["nuevoEmail"],
                                "colonia"=> $_POST["nuevaColonia"],
                                "tipo"=> $_POST["nuevoTipo"],
                                "sesion"=>$_SESSION["sesion"]
                                );
                    $respuesta = ModeloClientes::mdlIngresarCliente($tabla,$datos);
                    if($respuesta=="ok"){
                        echo'<script>
                    swal.fire({
                        icon:"success",
                        title: "Cliente registrado con éxito",
                        showConfirmButton: true,
                        confirmButtonText: "Cerrar",
                        closeOnConfirm: false 
                    }).then((result)=>{
                        if(result.value){
                            window.location="clientes";
                        }
                    });
                    </script>';
                    }   else{
                        echo'<script>
                    swal.fire({
                        icon:"error",
                        title: "Cliente no registrado con éxito",
                        showConfirmButton: true,
                        confirmButtonText: "Cerrar",
                        closeOnConfirm: false 
                    }).then((result)=>{
                        if(result.value){
                            window.location="clientes";
                        }
                    });
                    </script>';
                    }   
                
                }else{
                    echo'<script>
                    swal.fire({
                        icon:"error",
                        title: "¡No dejes campos vacíos! ",
                        showConfirmButton: true,
                        confirmButtonText: "Cerrar",
                        closeOnConfirm: false
                    }).then((result)=>{
                        if(result.value){
                            window.location="clientes";
                        }
                    });
                    </script>';
                }
        }
    }
    static public function ctrMostrarClientes($item,$valor){
        $tabla="clientes";
        $respuesta = ModeloClientes::MdlMostrarClientes($tabla,$item,$valor);
        return $respuesta;
    }
    /* Editar usuario */
    static public function ctrEditarCliente(){
            if(isset($_POST["editarNombre"])){
                if(preg_match('/^[-a-zA-Z0-9ñÑáéíóúÁÉÍÓÚ ]+$/', $_POST["editarNombre"])&&
                    preg_match('/^[0-9]+$/', $_POST["editarTelefono"])){
                    $tabla="clientes";
                        $datos = array( "id" => $_POST["idActual"],
                                        "nombre" => $_POST["editarNombre"],
                                        "telefono" => $_POST["editarTelefono"],
                                        "correo" => $_POST["editarEmail"],
                                        "colonia" => $_POST["editarColonia"],
                                        "tipo" => $_POST["editarTipo"]
                                    );
                        $respuesta=ModeloClientes::mdlEditarCliente($tabla,$datos);
                        if($respuesta=="ok"){
                            echo'<script>
                    swal.fire({
                        icon:"success",
                        title: "Cliente modificado con éxito",
                        showConfirmButton: true,
                        confirmButtonText: "Cerrar",
                        closeOnConfirm: false 
                    }).then((result)=>{
                        if(result.value){
                            window.location="clientes";
                        }
                    });
                    </script>';
                            }
                        }else{
                echo'<script>
                    swal.fire({
                        icon:"error",
                        title: "Verifique los datos ingresados",
                        showConfirmButton: true,
                        confirmButtonText: "Cerrar",
                        closeOnConfirm: false
                    }).then((result)=>{
                        if(result.value){
                            window.location="clientes";
                        }
                    });
                    </script>';
                }
            }
    }
    /* Borrar usuario */
    static public function ctrBorrarCliente(){
        if(isset($_GET["idCliente"])){
            $tabla="clientes";
            $datos=$_GET["idCliente"];
            $respuesta=ModeloClientes::mdlBorrarCliente($tabla,$datos);
            if($respuesta=="ok"){
                echo'<script>
                    swal.fire({
                        icon:"success",
                        title: "Cliente eliminado con éxito",
                        showConfirmButton: true,
                        confirmButtonText: "Cerrar",
                        closeOnConfirm: false 
                    }).then((result)=>{
                        if(result.value){
                            window.location="clientes";
                        }
                    });
                    </script>';
            }else{
                echo'<script>
                    swal.fire({
                        icon:"error",
                        title: "Cliente no eliminado con éxito",
                        showConfirmButton: true,
                        confirmButtonText: "Cerrar",
                        closeOnConfirm: false 
                    }).then((result)=>{
                        if(result.value){
                            window.location="clientes";
                        }
                    });
                    </script>';
            }
        }
    }
}