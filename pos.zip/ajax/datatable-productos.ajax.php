<?php
require_once "../controladores/productos.controlador.php";
require_once "../modelos/productos.modelo.php";
class TablaProductos
{
    /*=============================================
        mostrar la tabla productos                             
        =============================================*/
    public function mostarTablaProductos()
    {
        echo 'hola';
    }
}
/*=============================================
    Activar tabla productos                             
    =============================================*/
$activarProductos = new TablaProductos();
$activarProductos->mostarTablaProductos();
