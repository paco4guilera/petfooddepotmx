<?php 
require_once "../controladores/clientes.controlador.php";
require_once "../modelos/clientes.modelo.php";
class AjaxClientes{
    /* Editar usuario */
    public $idCliente;
    public function ajaxEditarCliente(){
        $item="cliente_id";
        $valor= $this->idCliente;
        $respuesta= ControladorClientes::ctrMostrarClientes($item,$valor);
        echo json_encode($respuesta);
    }
    public $validarTelefono;
    public function ajaxValidarTelefono(){
        $item="cliente_telefono";
        $valor=$this->validarTelefono;
        $respuesta= ControladorClientes::ctrMostrarClientes($item,$valor);
        echo json_encode($respuesta);
    }
    public $validarCorreo;
    public function ajaxValidarCorreo(){
        $item="cliente_correo";
        $valor=$this->validarCorreo;
        $respuesta= ControladorClientes::ctrMostrarClientes($item,$valor);
        echo json_encode($respuesta);
    }
    public $validarNombre;
    public function ajaxValidarNombre(){
        $item="cliente_nombre";
        $valor=$this->validarNombre;
        $respuesta= ControladorClientes::ctrMostrarClientes($item,$valor);
        echo json_encode($respuesta);
    }

}
if(isset($_POST["idCliente"])){
    $editar = new AjaxClientes();
    $editar-> idCliente= $_POST["idCliente"];
    $editar->ajaxEditarCliente();
}
if(isset($_POST["validarTelefono"])){
    $valTel = new AjaxClientes();
    $valTel-> validarTelefono=$_POST["validarTelefono"];
    $valTel->ajaxValidarTelefono();
}
if(isset($_POST["validarCorreo"])){
    $valCorreo = new AjaxClientes();
    $valCorreo-> validarCorreo=$_POST["validarCorreo"];
    $valCorreo->ajaxValidarCorreo();
}
if(isset($_POST["validarNombre"])){
    $valNombre = new AjaxClientes();
    $valNombre-> validarNombre=$_POST["validarNombre"];
    $valNombre->ajaxValidarNombre();
}