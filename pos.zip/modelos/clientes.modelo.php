<?php
require_once "conexion.php";
class ModeloClientes{
/* Mostrar usuarios */
    static public function mdlMostrarClientes($tabla,$item,$valor){
        if($item!=null){
        $stmt= Conexion::conectar()->prepare("SELECT * FROM $tabla WHERE $item = :$item ");
        $stmt-> bindParam(":".$item,$valor,PDO::PARAM_STR);
        
        $stmt->execute();
        return $stmt-> fetch();
        }else{
            $estado="cliente_estado";
            $val="1";
            $stmt= Conexion::conectar()->prepare("SELECT * FROM $tabla WHERE $estado = :$estado");
            $stmt-> bindParam(":".$estado,$val,PDO::PARAM_STR);
            $stmt->execute();
        return $stmt-> fetchAll();
        } 
        
        $stmt=null;
        
    }
    static public function mdlIngresarCliente($tabla,$datos){
        // $estado="1";
        // $numsesion=1;
        $stmt= Conexion::conectar()->prepare
        ("INSERT INTO $tabla (  cliente_nombre,
                                cliente_telefono,
                                cliente_correo,
                                cliente_colonia,
                                cliente_puntos,
                                cliente_tipo,
                                cliente_credito,
                                cliente_deuda,
                                cliente_estado,
                                sesion_id) 
        VALUES (:cliente_nombre,
                :cliente_telefono,
                :cliente_correo,
                :cliente_colonia,
                :cliente_puntos,
                :cliente_tipo,
                :cliente_credito,
                :cliente_deuda,
                :cliente_estado,
                :sesion_id) ");
        $val=0;
        $estado="1";
        $stmt->bindParam(":cliente_nombre",$datos["nombre"],PDO::PARAM_STR);
        $stmt->bindParam(":cliente_telefono",$datos["telefono"],PDO::PARAM_STR);
        $stmt->bindParam(":cliente_correo",$datos["correo"],PDO::PARAM_STR);
        $stmt->bindParam(":cliente_colonia",$datos["colonia"],PDO::PARAM_STR);
        $stmt->bindParam(":cliente_puntos",$val,PDO::PARAM_INT);
        $stmt->bindParam(":cliente_tipo",$datos["tipo"],PDO::PARAM_STR);
        $stmt->bindParam(":cliente_credito",$val,PDO::PARAM_STR);
        $stmt->bindParam(":cliente_deuda",$val,PDO::PARAM_STR);
        $stmt->bindParam(":cliente_estado",$estado,PDO::PARAM_STR);
        $stmt->bindParam(":sesion_id",$datos["sesion"],PDO::PARAM_INT);
        //$stmt->bindParam(":usuario_estado",$estado,PDO::PARAM_STR);
        // /* Reemplazar para que guarde la sesion actual */
        //$stmt->bindParam(":sesion_id",$numsesion,PDO::PARAM_INT);
        
        if($stmt->execute()){
            return "ok";
        }else{
            //var_dump($stmt->execute());
            return "error";
        }
        //$stmt->close();
        $stmt=null;
    }
    
    static public function mdlEditarCliente($tabla,$datos){
        $stmt= Conexion::conectar()->prepare
        ("UPDATE $tabla 
        SET cliente_nombre=:cliente_nombre,
        cliente_telefono=:cliente_telefono,
        cliente_correo=:cliente_correo,
        cliente_colonia=:cliente_colonia,
        cliente_tipo=:cliente_tipo
        WHERE cliente_id=:cliente_id");

        $stmt->bindParam(":cliente_nombre",$datos["nombre"],PDO::PARAM_STR);
        $stmt->bindParam(":cliente_telefono",$datos["telefono"],PDO::PARAM_STR);
        $stmt->bindParam(":cliente_correo",$datos["correo"],PDO::PARAM_STR);
        $stmt->bindParam(":cliente_colonia",$datos["colonia"],PDO::PARAM_STR);
        $stmt->bindParam(":cliente_tipo",$datos["tipo"],PDO::PARAM_STR);
        $stmt->bindParam(":cliente_id",$datos["id"],PDO::PARAM_INT);
        if($stmt->execute()){
            return "ok";
        }else{
            var_dump($stmt->execute());
            return "error";
        }
        //$stmt->close();
        $stmt=null;
    }
    /* Borrar cliente */
    static public function mdlBorrarCliente($tabla,$datos){
        $estado="0";
        $stmt= Conexion::conectar()->prepare("UPDATE $tabla 
                                                set cliente_estado=:cliente_estado
                                                WHERE cliente_id=:cliente_id");
        $stmt->bindParam(":cliente_estado",$estado,PDO::PARAM_STR);
        $stmt->bindParam(":cliente_id",$datos,PDO::PARAM_STR);
        if($stmt->execute()){
            return "ok";
        }else{
            //var_dump($stmt->execute());
            return "error";
        }
        //$stmt->close();
        $stmt=null;
        
    }
}